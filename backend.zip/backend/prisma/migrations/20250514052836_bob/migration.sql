-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "isShare" BOOLEAN NOT NULL DEFAULT false;
